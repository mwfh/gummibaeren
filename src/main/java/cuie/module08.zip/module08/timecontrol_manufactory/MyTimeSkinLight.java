
package cuie.module08.timecontrol_manufactory;

        import javafx.geometry.Insets;
        import javafx.scene.Node;
        import javafx.scene.control.Label;
        import javafx.scene.control.SkinBase;
        import javafx.scene.control.TextField;
        import javafx.scene.image.Image;
        import javafx.scene.image.ImageView;
        import javafx.scene.layout.Pane;
        import javafx.scene.layout.Region;
        import javafx.scene.layout.VBox;
        import javafx.scene.shape.Circle;
        import javafx.scene.shape.Ellipse;
        import javafx.util.converter.LocalTimeStringConverter;

        import java.awt.*;


class MyTimeSkinLight extends SkinBase<MyTimeControl> {
    private static final double ARTBOARD_WIDTH  = 140;
    private static final double ARTBOARD_HEIGHT = 532;

    private static final double ASPECT_RATIO = ARTBOARD_WIDTH / ARTBOARD_HEIGHT;

    private static final double MINIMUM_WIDTH  = 96;
    private static final double MINIMUM_HEIGHT = MINIMUM_WIDTH / ASPECT_RATIO;

    private static final double MAXIMUM_WIDTH = 300;

    // wird spaeter gebraucht
    private static final int ICON_SIZE  = 12;
    private static final int IMG_OFFSET = 4;

    private static ImageView invalidIcon = new ImageView(new Image(MyTimeSkin.class.getResource("icons/invalid.png").toExternalForm(),
            ICON_SIZE, ICON_SIZE,
            true, false));

    private static ImageView validIcon = new ImageView(new Image(MyTimeSkin.class.getResource("icons/valid.png").toExternalForm(),
            ICON_SIZE, ICON_SIZE,
            true, false));

    private Pane drawingPane;

    //todo: replace it
    //private Label placeHolder;
    private TextField editableTime;
    private Label captionLabel;
    private Ellipse ellipseLight;

    MyTimeSkinLight(MyTimeControl control) {
        super(control);
        initializeSelf();
        initializeParts();
        initializeDrawingPane();
        layoutParts();
        setupValueChangeListeners();
        setupBindings();
    }

    private void initializeSelf() {
        // getSkinnable().loadFonts("/fonts/Lato/Lato-Reg.ttf", "/fonts/Lato/Lato-Lig.ttf");
        getSkinnable().addStylesheetFiles("style.css");
    }

    private void initializeParts() {
        double center = 100 * 0.5;

        //placeHolder = new Label("To be replaced");
        editableTime = new TextField();
        editableTime.getStyleClass().add("editable-time");

        captionLabel = new Label();
        captionLabel.getStyleClass().add("caption-label");

        ellipseLight = new Ellipse(center, center, 50,50);
        ellipseLight.getStyleClass().add("ellipse-light");
    }

    private void initializeDrawingPane() {
        drawingPane = new Pane();
        drawingPane.getStyleClass().add("drawing-pane");
        drawingPane.setMaxSize(ARTBOARD_WIDTH, ARTBOARD_HEIGHT);
        drawingPane.setMinSize(ARTBOARD_WIDTH, ARTBOARD_HEIGHT);
        drawingPane.setPrefSize(ARTBOARD_WIDTH, ARTBOARD_HEIGHT);
    }

    private void layoutParts() {
        //getChildren().addAll(placeHolder);

        //getChildren().addAll(placeHolder);
        //alle Parts zur drawingPane hinzufügen
        drawingPane.getChildren().addAll(ellipseLight, captionLabel, editableTime);
        getChildren().add(drawingPane);
    }

    private void setupValueChangeListeners() {
    }

    private void setupBindings() {
        editableTime.textProperty().bindBidirectional(getSkinnable().actualTimeProperty(), new LocalTimeStringConverter()); //skin mit control verbinden
        captionLabel.textProperty().bind(getSkinnable().captionProperty());
    }

//    @Override
//    protected void layoutChildren() {
//        super.layoutChildren();
//        resize();
//    }
//    //Skalierung: Gesamte DrawingPane wird skaliert (Alle Custom Controls, die in DrawingPane sind werden mit skaliert)
//    //Höhen- und Breitenverhältnis bleibt immer gleich
//    private void resize() {
//        Insets padding         = getPadding();
//        double availableWidth  = getWidth() - padding.getLeft() - padding.getRight();
//        double availableHeight = getHeight() - padding.getTop() - padding.getBottom();
//
//        double width = Math.max(Math.min(Math.min(availableWidth, availableHeight * ASPECT_RATIO), MAXIMUM_WIDTH), MINIMUM_WIDTH);
//
//        double scalingFactor = width / ARTBOARD_WIDTH;
//
//        if (availableWidth > 0 && availableHeight > 0) {
//            drawingPane.relocate((getWidth() - ARTBOARD_WIDTH) * 0.5, (getHeight() - ARTBOARD_HEIGHT) * 0.5);
//            drawingPane.setScaleX(scalingFactor);
//            drawingPane.setScaleY(scalingFactor);
//        }
//    }
}
